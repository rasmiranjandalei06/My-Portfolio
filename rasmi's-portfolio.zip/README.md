# Rasmi Ranjan Dalei - Portfolio

A journey from nothing to something.

## Deployment to GitHub Pages

This project is configured for easy deployment to GitHub Pages.

### Option 1: Automatic Deployment (Recommended)

1.  Push your code to a GitHub repository.
2.  The included GitHub Action (`.github/workflows/deploy.yml`) will automatically build and deploy your site to GitHub Pages on every push to the `main` branch.
3.  Go to your repository settings on GitHub, navigate to **Pages**, and ensure the **Source** is set to **GitHub Actions**.

### Option 2: Manual Deployment

If you prefer to deploy manually from your local machine:

1.  Run `npm run deploy`.
2.  This will build the project and push the `dist` folder to a `gh-pages` branch on your repository.
3.  Go to your repository settings on GitHub, navigate to **Pages**, and ensure the **Source** is set to **Deploy from a branch**, selecting the `gh-pages` branch.

## Environment Variables

If you are using the Gemini API, you will need to set up your `GEMINI_API_KEY` in your GitHub repository's **Secrets and Variables** (under **Actions**) if you use Option 1. For Option 2, ensure it's in your local `.env` file during the build.
